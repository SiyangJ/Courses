#ifndef ACTOR_H_
#define ACTOR_H_

#include "GraphObject.h"

// Students:  Add code to this file, Actor.cpp, StudentWorld.h, and StudentWorld.cpp

class StudentWorld;
class Bullet;

class AllThings : public GraphObject
{
public:
    AllThings(int imageID, int startX, int startY, Direction dir, int sub_level);
    
    virtual void doSomething(){}                 // Do nothing, e.g. the wall and fake walls;
    virtual void beingAttacked(Bullet* bl){}
    virtual void pickUpGoodie(){}
    virtual bool isObstacle(){return false;}
    virtual bool isObstruction(){return true;}
    virtual void goDie(){}
    virtual void thingsBeforeDying(){}
    virtual bool isDead(){return m_isDead;}
    void         setDead(bool amIDead){m_isDead=amIDead;}
private:
    bool m_isDead;
};

class Actor : public AllThings
{
public:
    Actor(int imageID, int startX, int startY, Direction dir, int sub_level, StudentWorld* stdWorld);
    StudentWorld* getWorld(){return m_studentWorld;}
    virtual void goDie();                         
    virtual void thingsBeforeDying(){}
    virtual void iAmAlive(){}
    virtual void checkAlive(){}
    virtual void doSomething()
    {
        checkAlive();
        if (!isDead())
        {
            iAmAlive();
            return;
        }
    }
private:
    StudentWorld* m_studentWorld;
    
};

class MovingThings : public Actor
{
public:
    MovingThings(int imageID, int startX, int startY, Direction dir, int sub_level, StudentWorld* stdWorld);
    virtual void fire();
    virtual void moveTick();
    virtual void notPassableThenWhat(){}
    virtual void thingsAfterMoving(){}
    virtual void beingAttacked(Bullet*){}
    virtual bool canMove(){return true;}
    virtual bool canFire()=0;
    virtual bool canDoOther(){return false;}
    virtual void decAmmo(){}
    virtual void iAmAlive()
    {
        if (!canMove()) return;
        if (canFire())
            fire();
        else if (canDoOther());
        else moveTick();
        thingsAfterMoving();
    }
    
private:
    
};
class BadGuys : public MovingThings
{
public:
    BadGuys(int imageID, int startX, int startY, Direction dir,int sub_level, StudentWorld* stdWorld, unsigned int hitP)
    : MovingThings(imageID, startX, startY, dir, sub_level, stdWorld),m_restTick(0),m_hitPoints(hitP)
    {}
    virtual bool canMove();
    virtual bool canFire();
    virtual void checkAlive();
    virtual void beingAttacked(Bullet*);
    virtual void thingsBeforeDying();
    virtual void dropThings()=0;
    virtual bool isObstacle(){return true;}
private:
    int          m_hitPoints;
    unsigned int m_ammo;
    unsigned int m_restTick;
};
class EventTrigger : public Actor
{
public:
    EventTrigger(int imageID, int startX, int startY, int sub_level, StudentWorld* stdWorld);
    virtual void triggerPlayer(){}
    virtual void iAmAlive();
    virtual bool isObstruction(){return false;}
};

class TotallyStatic : public AllThings
{
public:
    TotallyStatic(int imageID, int startX, int startY, int sub_level);
    virtual void beingAttacked(Bullet* bl);
    virtual bool isObstacle(){return true;}
};


class Player : public MovingThings
{
public:
    Player(int startX, int startY, int sub_level, StudentWorld* stdWorld);
    virtual bool canFire();
    virtual bool canDoOther();
    virtual void decAmmo();
    virtual void checkAlive();
    virtual void thingsBeforeDying();
    virtual void beingAttacked(Bullet*);
private:
    int m_action;
};
class Gangster : public BadGuys
{
public:
    Gangster(int startX, int startY, Direction dir, int sub_level, StudentWorld* stdWorld);
    virtual void dropThings();
};
class Horiz_Gangster : public Gangster
{
public:
    Horiz_Gangster(int startX, int startY, int sub_level, StudentWorld* stdWorld);
    virtual void notPassableThenWhat(){setDirection(getDirection()==left?right:left);}
    
};
class Vertic_Gangster : public Gangster
{
public:
    Vertic_Gangster(int startX, int startY, int sub_level, StudentWorld* stdWorld);
    virtual void notPassableThenWhat(){setDirection(getDirection()==up?down:up);}
};

class BullyNest : public Actor
{
public:
    BullyNest(int startX, int startY, int sub_level, StudentWorld* stdWorld);
    virtual bool isObstacle(){return true;}
    virtual void iAmAlive();
};
class RobotBoss : public BadGuys
{
public:
    RobotBoss(int startX, int startY, int sub_level, StudentWorld* stdWorld);
    virtual void dropThings();
    virtual void notPassableThenWhat()
    {
        switch (getDirection()) {
            case up:    setDirection(down);  break;
            case down:  setDirection(up);    break;
            case left:  setDirection(right); break;
            case right: setDirection(left);  break;
            default: break;
        }
    }
};
class Bullet : public MovingThings
{
public:
    Bullet(int startX, int startY, int sub_level, Direction dir, StudentWorld* stdWorld);
    virtual bool canFire();
    virtual void thingsAfterMoving();
    void         doSomeDamage();
    virtual void thingsBeforeDying();
    virtual bool isObstruction(){return false;};
    virtual void fire(){}
    
};
class Exit : public EventTrigger
{
public:
    Exit(int startX, int startY, int sub_level, StudentWorld* stdWorld);
    virtual void iAmAlive();
    virtual void triggerPlayer();
private:
    bool isComplete;
};
class Wall : public TotallyStatic
{
public:
    Wall(int startX, int startY, int sub_level);
};
class FakeWall : public TotallyStatic
{
public:
    FakeWall(int startX, int startY, int sub_level);
    virtual bool isObstruction(){return false;}
    virtual void beingAttacked(Bullet* bl){}
};
class Hostage : public EventTrigger
{
public:
    Hostage(int startX, int startY, int sub_level, StudentWorld* stdWorld);
    virtual void triggerPlayer();
};
class Gate : public EventTrigger
{
public:
    Gate(int startX, int startY, int sub_level, StudentWorld* stdWorld, unsigned int toLevel);
    virtual void triggerPlayer();
private:
    unsigned int m_toLevel;
};
class Gold : public EventTrigger
{
public:
    Gold(int startX, int startY, int sub_level, StudentWorld* stdWorld);
    virtual void triggerPlayer();
};
class ExtraLife : public EventTrigger
{
public:
    ExtraLife(int startX, int startY, int sub_level, StudentWorld* stdWorld);
    virtual void triggerPlayer();
};
class RestoreHealth : public EventTrigger
{
public:
    RestoreHealth(int startX, int startY, int sub_level, StudentWorld* stdWorld);
    virtual void triggerPlayer();
};
class Ammo : public EventTrigger
{
public:
    Ammo(int startX, int startY, int sub_level, StudentWorld* stdWorld);
    virtual void triggerPlayer();
};
class Waterpool : public Actor
{
public:
    Waterpool(int startX, int startY, int sub_level, StudentWorld* stdWorld);
    virtual void beingAttacked(Bullet* bl){bl->goDie();}
    virtual void iAmAlive(){if (m_hitPoints==0) {setDead(true); setVisible(false); return;} m_hitPoints--;}
    virtual bool isObstacle(){return true;}
    virtual bool isObstruction(){return true;}
private:
    unsigned int m_hitPoints;
};
class FarplaneGun : public EventTrigger
{
public:
    FarplaneGun(int startX, int startY, int sub_level, StudentWorld* stdWorld);
    virtual void goDie();
    virtual void triggerPlayer();
};
class Bully : public BadGuys
{
public:
    Bully(int startX, int startY, int sub_level, StudentWorld* stdWorld);
    virtual void dropThings();
    virtual bool canDoOther();
    virtual void notPassableThenWhat();
private:
    virtual void turning();
    std::map<int,unsigned int> m_goodies;
    unsigned int m_distanceBeforeTurning;
    unsigned int m_curDistance;
    
};

#endif // ACTOR_H_
