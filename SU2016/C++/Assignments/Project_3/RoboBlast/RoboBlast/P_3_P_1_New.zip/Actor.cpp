 #include "Actor.h"
#include "StudentWorld.h"
#include <algorithm>

using namespace std;

// Students:  Add code to this file (if you wish), Actor.h, StudentWorld.h, and StudentWorld.cpp

// Constructors:

AllThings::AllThings(int imageID, int startX, int startY, Direction dir, int sub_level)
: GraphObject(imageID, startX, startY, dir, sub_level),m_isDead(false)
{}

Actor::Actor(int imageID, int startX, int startY, Direction dir, int sub_level, StudentWorld* stdWorld)
: AllThings(imageID, startX, startY, dir, sub_level), m_studentWorld(stdWorld)
{}

MovingThings::MovingThings(int imageID, int startX, int startY, Direction dir, int sub_level, StudentWorld* stdWorld)
: Actor(imageID, startX, startY, dir, sub_level, stdWorld)
{}

EventTrigger::EventTrigger(int imageID, int startX, int startY, int sub_level, StudentWorld* stdWorld)
: Actor(imageID, startX, startY, none, sub_level, stdWorld)
{}

TotallyStatic::TotallyStatic(int imageID, int startX, int startY, int sub_level)
: AllThings(imageID, startX, startY, none, sub_level)
{}

Player::Player(int startX, int startY, int sub_level, StudentWorld* stdWorld)
: MovingThings(IID_PLAYER, startX, startY, right, sub_level, stdWorld)
{}

Gangster::Gangster(int startX, int startY, Direction dir, int sub_level, StudentWorld* stdWorld)
: BadGuys(IID_GANGSTER,startX,startY,dir,sub_level,stdWorld,10)
{}

Horiz_Gangster::Horiz_Gangster(int startX, int startY, int sub_level, StudentWorld* stdWorld)
: Gangster(startX, startY, right, sub_level, stdWorld)
{}

Vertic_Gangster::Vertic_Gangster(int startX, int startY, int sub_level, StudentWorld* stdWorld)
: Gangster(startX, startY, down, sub_level, stdWorld)
{}

Bully::Bully(int startX, int startY, int sub_level, StudentWorld* stdWorld)
: BadGuys(IID_BULLY,startX,startY,right,sub_level,stdWorld,5)
{
    m_goodies[IID_RESTORE_HEALTH]=0;
    m_goodies[IID_AMMO]=0;
    m_goodies[IID_EXTRA_LIFE]=0;
    setVisible(true);
    m_distanceBeforeTurning=rand()%6+1;
    m_curDistance=0;
}

BullyNest::BullyNest(int startX, int startY, int sub_level, StudentWorld* stdWorld)
: Actor(IID_BULLY_NEST, startX, startY, none, sub_level, stdWorld)
{
    setDead(false);
}

RobotBoss::RobotBoss(int startX, int startY, int sub_level, StudentWorld* stdWorld)
: BadGuys(IID_ROBOT_BOSS,startX,startY,right,sub_level,stdWorld,50)
{}

Bullet::Bullet(int startX, int startY, int sub_level, Direction dir, StudentWorld* stdWorld)
: MovingThings(IID_BULLET, startX, startY, dir, sub_level, stdWorld)
{
    setVisible(true);
}

Exit::Exit(int startX, int startY, int sub_level, StudentWorld* stdWorld)
: EventTrigger(IID_EXIT, startX, startY, sub_level, stdWorld),isComplete(false)
{}

Wall::Wall(int startX, int startY, int sub_level)
: TotallyStatic(IID_WALL, startX, startY, sub_level)
{}

FakeWall::FakeWall(int startX, int startY, int sub_level)
: TotallyStatic(IID_FAKE_WALL, startX, startY, sub_level)
{}

Hostage::Hostage(int startX, int startY, int sub_level, StudentWorld* stdWorld)
: EventTrigger(IID_HOSTAGE, startX, startY, sub_level, stdWorld)
{}

Gate::Gate(int startX, int startY, int sub_level, StudentWorld* stdWorld, unsigned int toLevel)
: EventTrigger(IID_GATE, startX, startY, sub_level, stdWorld), m_toLevel(toLevel)
{}

Gold::Gold(int startX, int startY, int sub_level, StudentWorld* stdWorld)
: EventTrigger(IID_GOLD, startX, startY, sub_level, stdWorld)
{}

ExtraLife::ExtraLife(int startX, int startY, int sub_level, StudentWorld* stdWorld)
: EventTrigger(IID_EXTRA_LIFE, startX, startY, sub_level, stdWorld)
{}

RestoreHealth::RestoreHealth(int startX, int startY, int sub_level, StudentWorld* stdWorld)
: EventTrigger(IID_RESTORE_HEALTH, startX, startY, sub_level, stdWorld)
{}

Ammo::Ammo(int startX, int startY, int sub_level, StudentWorld* stdWorld)
: EventTrigger(IID_AMMO, startX, startY, sub_level, stdWorld)
{}

Waterpool::Waterpool(int startX, int startY, int sub_level, StudentWorld* stdWorld)
: Actor(IID_WATERPOOL, startX, startY, none, sub_level, stdWorld),m_hitPoints(30)
{
    setVisible(true);
}

FarplaneGun::FarplaneGun(int startX, int startY, int sub_level, StudentWorld* stdWorld)
: EventTrigger(IID_FARPLANE_GUN, startX, startY, sub_level, stdWorld)
{}


// Some general functions to drive things

void Actor::goDie()
{
    thingsBeforeDying();
    this->setVisible(false);
    setDead(true);
}

void MovingThings::moveTick()
{
    int dx=0,dy=0;
    switch (getDirection()) {
        case up:    dy=1;  break;
        case down:  dy=-1; break;
        case left:  dx=-1; break;
        case right: dx=1;  break;
        default:break;
    }
    if (getID()==IID_BULLET || getWorld()->isPassable(getX()+dx, getY()+dy))
        moveTo(getX()+dx, getY()+dy);
    else
        notPassableThenWhat();
}

void EventTrigger::iAmAlive()
{
    if (getX()==getWorld()->getPlayer()->getX()&&
        getY()==getWorld()->getPlayer()->getY())
        triggerPlayer();
}

// How things specifically work
void MovingThings::fire()
{
    int dx=0,dy=0;
    switch (getDirection()) {
        case up:    dy=1;  break;
        case down:  dy=-1; break;
        case left:  dx=-1; break;
        case right: dx=1;  break;
        default:break;
    }
    AllThings* newBl=new Bullet(getX(),getY(),getWorld()->getCurrentSubLevel(),getDirection(),getWorld());
    getWorld()->getAllThings()->push_back(newBl);
    newBl->moveTo(getX()+dx, getY()+dy);
    if (getID()!=IID_PLAYER)
        getWorld()->playSound(SOUND_ENEMY_FIRE);
    else getWorld()->playSound(SOUND_PLAYER_FIRE);
    decAmmo();
}


void BadGuys::beingAttacked(Bullet* bl)
{
    m_hitPoints=((m_hitPoints-2)>0?(m_hitPoints-2):0);
    bl->goDie();
    if (m_hitPoints>0) getWorld()->playSound(SOUND_ENEMY_IMPACT);
}

bool BadGuys::canFire()
{
    vector<AllThings*>::iterator it;
    if (getDirection()==up || getDirection()==down)
    {
        if (getX()==getWorld()->getPlayer()->getX())
        {
            for (it=getWorld()->getAllThings()->begin();it!=getWorld()->getAllThings()->end();it++)
            {
                if ((*it)->getX()==getX() && (*it)!=this &&
                    (*it)->getY()>fmin(getY(), getWorld()->getPlayer()->getY()) &&
                    (*it)->getY()<fmax(getY(), getWorld()->getPlayer()->getY())
                    )
                {
                    if ((*it)->isObstacle())
                        return false;
                }
            }
            if (getY()<getWorld()->getPlayer()->getY())
            {
                if (getDirection()!=up) return false;
            }
            else
            {
                if (getDirection()!=down) return false;
            }
        }
        else return false;
    }
    else if (getDirection()==left || getDirection()==right)
    {
        if (getY()==getWorld()->getPlayer()->getY())
        {
            for (it=getWorld()->getAllThings()->begin();it!=getWorld()->getAllThings()->end();it++)
            {
                if ((*it)->getY()==getY() && (*it)!=this &&
                    (*it)->getX()>fmin(getX(), getWorld()->getPlayer()->getX()) &&
                    (*it)->getX()<fmax(getX(), getWorld()->getPlayer()->getX())
                    )
                {
                    if ((*it)->isObstacle())
                        return false;
                }
            }
            if (getX()<getWorld()->getPlayer()->getX())
            {
                if (getDirection()!=right) return false;
            }
            else
            {
                if (getDirection()!=left) return false;
            }
        }
        else return false;
    }
    return true;
}

bool BadGuys::canMove()     //////////////////!!!!!!!BUG!!!!!!!/////////////////////////FrequencySomehowTooLow
{
    int f=(28-getWorld()->getLevel())/4;
    bool r;
    if (f<3) f=3;
    r=(m_restTick%f==0);
    m_restTick++;
    return(r);
}

void BadGuys::thingsBeforeDying()
{
    getWorld()->playSound(SOUND_ENEMY_DIE);
    getWorld()->increaseScore(getID()==IID_ROBOT_BOSS ? 3000:(getID()==IID_GANGSTER ? 100:10));
    dropThings();
}

void BadGuys::checkAlive()
{
    if (m_hitPoints==0 && isDead()==false)
        goDie();
}

void TotallyStatic::beingAttacked(Bullet* bl)
{bl->goDie();}

void Player::checkAlive()
{
    if (getWorld()->getHitpoints()<=0 && isDead()==false)
        goDie();
}

void Player::thingsBeforeDying()
{
    getWorld()->setStatus(GWSTATUS_PLAYER_DIED);
    getWorld()->playSound(SOUND_PLAYER_DIE);
}

bool Player::canFire()
{
    m_action=0;
    getWorld()->getKey(m_action);
    switch (m_action) {
        case KEY_PRESS_ESCAPE: getWorld()->setStatus(GWSTATUS_PLAYER_DIED); break;
        case KEY_PRESS_SPACE:  {
                                if (getWorld()->getAmmo()>0)  return true;
                                else m_action=0;
                                break;
                                }
        case KEY_PRESS_UP:     setDirection(up);             break;
        case KEY_PRESS_DOWN:   setDirection(down);           break;
        case KEY_PRESS_LEFT:   setDirection(left);           break;
        case KEY_PRESS_RIGHT:  setDirection(right);          break;
        case KEY_PRESS_TAB:    m_action=0;                   break;
        default: break;
    }
    return false;
}

bool Player::canDoOther()
{
    if (m_action==0 || m_action==KEY_PRESS_ESCAPE)
        return true;
    return false;
}

void Player::beingAttacked(Bullet* bl)
{
    if (getWorld()->getHitpoints()>=2)
        getWorld()->decHitpoints(2);
    else (getWorld()->setHitpoints(0));
    bl->goDie();
    if (getWorld()->getHitpoints()>0) getWorld()->playSound(SOUND_PLAYER_IMPACT);
}

void Player::decAmmo()
{
    getWorld()->useAmmo();
}

void Bullet::doSomeDamage()
{
    // Traverse
    vector<AllThings*>::iterator it;
    for (it=getWorld()->getAllThings()->begin();it!=getWorld()->getAllThings()->end();it++)
    {
        if ((*it)->getX()==getX()&&(*it)->getY()==getY()&&(*it)!=this)
        {
            moveTo(getX(), getY());
            (*it)->beingAttacked(this);
            if (isDead())
                break;
        }
    }
}

void Bullet::thingsBeforeDying()
{}

bool Bullet::canFire()
{
    doSomeDamage();
    return false;
}

void Bullet::thingsAfterMoving()
{
    if (isDead()==false)
        doSomeDamage();
}

void Bully::turning()
{
    m_curDistance=0;
    m_distanceBeforeTurning=rand()%6+1;
    Direction arrDir[4]={up,down,left,right};
    int newDir=rand()%4;
    int i;
    for (i=0;i<4;i++)
    {
        int j=(i+newDir)%4;
        int dx=0,dy=0;
        if (j/2==0)
            dy=(j%2==0?1:-1);
        else
            dx=(j%2==0?-1:1);
        if (getWorld()->isPassable(getX()+dx, getY()+dy))
        {
            setDirection(arrDir[j]);
            moveTo(getX()+dx, getY()+dy);
        }
    }
    if (i==4)
    {
        setDirection(arrDir[newDir]);
    }
}

bool Bully::canDoOther()
{
    bool itCanDoOther=false;
    vector<AllThings*>::iterator it;
    for (it=getWorld()->getAllThings()->begin();it!=getWorld()->getAllThings()->end();it++)
    {
        if ((*it)->getX()==getX() && (*it)->getY()==getY())
        {
            if ((*it)->getID()==IID_AMMO || (*it)->getID()==IID_RESTORE_HEALTH || (*it)->getID()==IID_EXTRA_LIFE)
            {
                m_goodies[(*it)->getID()]++;
                getWorld()->playSound(SOUND_BULLY_MUNCH);
                (*it)->goDie();
                itCanDoOther=true;
            }
        }
    }
    if (!itCanDoOther)
    {
        if (m_curDistance<m_distanceBeforeTurning)
        {
            m_curDistance++;
            return false;
        }
        else
        {
            turning();
            return true;
        }
    }
    return itCanDoOther;
}

void Bully::notPassableThenWhat()
{
    turning();
}

void Bully::dropThings()
{
    for (int j=0;j<m_goodies[IID_AMMO];j++)
    {
        AllThings* newAmmo=new Ammo(getX(),getY(),getWorld()->getCurrentSubLevel(),getWorld());
        getWorld()->getAllThings()->push_back(newAmmo);
        newAmmo->setVisible(true);
    }
    for (int j=0;j<m_goodies[IID_RESTORE_HEALTH];j++)
    {
        AllThings* newResH=new RestoreHealth(getX(),getY(),getWorld()->getCurrentSubLevel(),getWorld());
        getWorld()->getAllThings()->push_back(newResH);
        newResH->setVisible(true);
    }
    for (int j=0;j<m_goodies[IID_EXTRA_LIFE];j++)
    {
        AllThings* newExL=new ExtraLife(getX(),getY(),getWorld()->getCurrentSubLevel(),getWorld());
        getWorld()->getAllThings()->push_back(newExL);
        newExL->setVisible(true);
    }
}

void Gangster::dropThings()
{
    AllThings* newWP=new Waterpool(getX(),getY(),getWorld()->getCurrentSubLevel(),getWorld());
    getWorld()->getAllThings()->push_back(newWP);
}

void RobotBoss::dropThings()
{
    AllThings* newHos=new Hostage(getX(),getY(),getWorld()->getCurrentSubLevel(),getWorld());
    getWorld()->getAllThings()->push_back(newHos);
    newHos->setVisible(true);
}

void BullyNest::iAmAlive()
{
    unsigned int count=0;
    vector<AllThings*>::iterator it;
    for (it=getWorld()->getAllThings()->begin();it!=getWorld()->getAllThings()->end();it++)
    {
        if ((*it)->getID()==IID_BULLY)
        {
            if (((*it)->getX()<=getX()+3 && (*it)->getX()>=getX()-3) && ((*it)->getY()<=getY()+3 && (*it)->getY()>=getY()-3))
            {
                if ((*it)->getX()==getX()&&(*it)->getY()==getY())
                {
                    count=3;
                    break;
                }
                count++;
            }
        }
    }
    if (count<3)
    {
        if ((rand()%50)==0)
        {
            getWorld()->getAllThings()->push_back(new Bully(getX(),getY(),getWorld()->getCurrentSubLevel(),getWorld()));
            getWorld()->playSound(SOUND_BULLY_BORN);
        }
    }
}

void Gate::triggerPlayer()
{
    getWorld()->toSublevel(m_toLevel);
    goDie();
}

void Gold::triggerPlayer()
{
    getWorld()->increaseScore(100);
    getWorld()->playSound(SOUND_GOT_GOLD);
    goDie();
}

void Ammo::triggerPlayer()
{
    getWorld()->gainAmmo(25);
    getWorld()->increaseScore(150);
    getWorld()->playSound(SOUND_GOT_GOODIE);
    goDie();
}

void FarplaneGun::goDie()
{
    thingsBeforeDying();
    setDead(true);
}

void FarplaneGun::triggerPlayer()
{
    if (getWorld()->getHitpoints()>=10)
        getWorld()->decHitpoints(10);
    else getWorld()->setHitpoints(0);
    vector<AllThings*>::iterator it;
    for (it=getWorld()->getAllThings()->begin();it!=getWorld()->getAllThings()->end();it++)
    {
        if (((*it)->getX()<=getX()+4 && (*it)->getX()>=getX()-4) && ((*it)->getY()<=getY()+4 && (*it)->getY()>=getY()-4))
        {
            if ((*it)->getID()==IID_BULLY || (*it)->getID()==IID_GANGSTER)
                (*it)->goDie();
        }
    }
    getWorld()->playSound(SOUND_GOT_FARPLANE_GUN);
    goDie();
}

void ExtraLife::triggerPlayer()
{
    getWorld()->increaseScore(150);
    getWorld()->incLives();
    getWorld()->playSound(SOUND_GOT_GOODIE);
    goDie();
}

void RestoreHealth::triggerPlayer()
{
    getWorld()->increaseScore(250);
    getWorld()->setHitpoints(INITIAL_HITPOINTS);
    getWorld()->playSound(SOUND_GOT_GOODIE);
    goDie();
}

void Exit::iAmAlive()
{
    if (!isComplete)
    {
        vector<AllThings*>::iterator it;
        for (int j=0;j<=getWorld()->getSublevel();j++)
        {
            for (it=getWorld()->getAllThings(j)->begin();it!=getWorld()->getAllThings(j)->end();it++)
            {
                if ((*it)->getID()==IID_GOLD || (*it)->getID()==IID_ROBOT_BOSS || (*it)->getID()==IID_HOSTAGE)
                    return;
            }
        }
        isComplete=true;
        if (getWorld()->getCurrentSubLevel()==0)
        {
            setVisible(true);
            getWorld()->playSound(SOUND_REVEAL_EXIT);
        }
    }
    else
    {
        if (getWorld()->getCurrentSubLevel()==0)
        {
            setVisible(true);
        }
        if (getX()==getWorld()->getPlayer()->getX()&&
            getY()==getWorld()->getPlayer()->getY())
            triggerPlayer();
    }
}

void Exit::triggerPlayer()
{
    getWorld()->setStatus(GWSTATUS_FINISHED_LEVEL);
    getWorld()->playSound(SOUND_FINISHED_LEVEL);
    getWorld()->increaseScore(getWorld()->getTick()+1500);
}

void Hostage::triggerPlayer()
{
    getWorld()->playSound(SOUND_GOT_GOODIE);
    goDie();
}
