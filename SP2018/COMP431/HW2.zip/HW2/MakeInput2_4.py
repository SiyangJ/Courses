# Description: Valid sequence with some invalid commands in it
#  1. Early Quit

import sys


sys.stdout.write("QUIT\r\n")

sys.stdout.write("PorT 152,25,124,131,31,144\r\n")
sys.stdout.write("User Jasleen\r\n")
