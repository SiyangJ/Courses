# Description:
# Valid Sequence of inputs and outputs with absolutely no errors at all.
# WARNING: You must create your own file in the same directory called still_relative

import sys

sys.stdout.write("User kevin!!??\r\n")
sys.stdout.write("pass password12345\r\n")
sys.stdout.write("tyPe A\r\n")
sys.stdout.write("sYSt\r\n")
sys.stdout.write("PorT 152,25,124,131,31,144\r\n")
# CAREFUL!!!
sys.stdout.write("rEtr /still_relative\r\n")
sys.stdout.write("QUIT\r\n")